@extends('app.base')
@section('title', 'Argo Create Game') <!-- Cambiar 'Movie' por 'Game' -->
@section('content')
<div class="card">
 <div class="card-header">
 <strong class="card-title">Custom Table</strong>
 </div>
 <div class="table-stats order-table ov-h">
                                <table class="table ">
                                    <thead>
                                        <tr>
                <th scope="col">#</th>
                <th scope="col">Title</th>
                <th scope="col">Price</th> <!-- Cambiar 'Director' y 'Year' por 'Price' y 'Sales' -->
                <th scope="col">Sales</th>
                <th scope="col">genero</th>
                 <th scope="col">desarrollador</th>
                  <th scope="col">plataforma</th>
                   <th scope="col"></th>
            </tr>
                                    </thead>
                                    <tbody>
                                         
            @foreach($games as $game) <!-- Cambiar 'movies' por 'games' -->
                <tr>
                    <td>{{ $game->id }} </td>
                    <td>{{ $game->title }}</td>
                    <td>{{ $game->price }}</td>
                    <td>{{ $game->sales }}</td>
                    <td>{{ $game->genero }}</td>
                    <td>{{ $game->desarrollador }}</td>
                    <td>{{ $game->plataforma }}</td>
                    <td>
                        <a href="{{ url('game/' . $game->id) }}" class="btn btn-primary">View</a>
                        <a href="{{ url('game/' . $game->id . '/edit')}}" class="btn btn-success"><i class="fa fa-magic"></i>Edit</a> 
        <form class="formDelete" action="{{ url('game/' . $game->id) }}" method="post" style="display: inline-block">
                        @csrf
                        @method('delete')
                        <button class="btn-danger btn" type="submit" >Delete</button>
                    </form>
                </td>
            </tr>
            @endforeach
</tbody>
</table>
             <a class="btn-primary btn" href="{{ url('game/create') }}"><i class="fa fa-plus"></i>Link to create</a>
    <form id = "formDelete" action = "{{ url ('') }}" method = "post" style = "display: inline-block"> 
    @csrf
    @method('delete')
    </form>              
                          
                            </div> <!-- /.table-stats -->
                        </div>
                <script>
    const forms = document.querySelectorAll(".formDelete");
    forms.forEach(function(form){
        form.onsubmit = () => {
            return confirm("Seguro?");
        }
    });
    
    const ahrefs = document.querySelectorAll(".hrefDelete");
    ahrefs.forEach(function(ahref){
        ahref.onclick = (event) => {
            let url = event.target.dataset.url;
            if (confirm('Seguro?')) {
                let formDelete = document.getElementById("formDelete");
                formDelete.action = url;
                event.preventDefault();
                formDelete.submit();
            }
        }
    });
</script>        
                        
                        
            
@endsection
