@extends('app.base')

@section('title', 'Argo Movie')

@section('content')
<div class="table-responsive small">
    <table class="table table-striped table-sm">
        <tbody>
            <tr>
                <td>#</td>
                <td>{{ $game->id }}</td>
            </tr>
            <tr>
                <td>Title</td>
                <td>{{ $game->title }}</td>
            </tr>
            <tr>
                <td>Price</td>
                <td>{{ $game->price }}</td>
            </tr>
            <tr>
                <td>Sales</td>
                <td>{{ $game->sales }}</td>
            </tr>
         <tr>
                <td>genero</td>
                <td>{{ $game->genero }}</td>
            </tr>
            <tr>
                <td>desarrollador</td>
                <td>{{ $game->desarrollador }}</td>
            </tr>
             <tr>
                <td>plataforma</td>
                <td>{{ $game->plataforma }}</td>
            </tr>
        </tbody>
    </table>
</div>
@endsection