@extends('app.base')

@section('title', 'Argo Movie')

@section('content')
<div class="table-responsive small">
    <table class="table table-striped table-sm">
        <tbody>
            <tr>
                <td>#</td>
                <td>{{ $game->id }}</td>
            </tr>
            <tr>
                <td>Title</td>
                <td>{{ $game->title }}</td>
            </tr>
            <tr>
                <td>Price</td>
                <td>{{ $game->price }}</td>
            </tr>
            <tr>
                <td>Sales</td>
                <td>{{ $game->sales }}</td>
            </tr>
         <tr>
                <td>genero</td>
                <td>{{ $game->genero }}</td>
            </tr>
            <tr>
                <td>desarrollador</td>
                <td>{{ $game->desarrollador }}</td>
            </tr>
             <tr>
                <td>plataforma</td>
                <td>{{ $game->plataforma }}</td>
            </tr>
        </tbody>
    </table>
    <a href="{{ url('game/' . $game->id . '/edit')}}" class="btn btn-success"><i class="fa fa-magic"></i>Edit</a> 
     <a href="{{ url('game/') }}" class="btn btn-primary">Back</a>
     <form class="formDelete" action="{{ url('game/' . $game->id) }}" method="post" style="display: inline-block">
                        @csrf
                        @method('delete')
                        <button class="btn-danger btn" type="submit" >Delete</button>
                    </form>
        <form id = "formDelete" action = "{{ url ('') }}" method = "post" style = "display: inline-block"> 
        <script>
    const forms = document.querySelectorAll(".formDelete");
    forms.forEach(function(form){
        form.onsubmit = () => {
            return confirm("Seguro?");
        }
    });
    
    const ahrefs = document.querySelectorAll(".hrefDelete");
    ahrefs.forEach(function(ahref){
        ahref.onclick = (event) => {
            let url = event.target.dataset.url;
            if (confirm('Seguro?')) {
                let formDelete = document.getElementById("formDelete");
                formDelete.action = url;
                event.preventDefault();
                formDelete.submit();
            }
        }
    });
</script>        
</div>
@endsection