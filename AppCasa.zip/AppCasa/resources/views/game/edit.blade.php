@extends('app.base')

@section('title', 'Edit Game')

@section('content')

    <form action="{{ url('game/'.$game->id) }}" method="post">
        @csrf
        @method('put')

        <!-- Inputs del formulario -->
        <div class="mb-3">
            <label for="title" class="form-label">Game title</label>
            <input type="text" class="form-control" id="title" name="title" maxlength="60" required value="{{ old('title', $game->title) }}">
        </div>

        <div class="mb-3">
            <label for="price" class="form-label">Game price</label>
            <input type="number" class="form-control" id="price" name="price" required value="{{ old('price', $game->price) }}">
        </div>

        <div class="mb-3">
            <label for="sales" class="form-label">Game sales</label>
            <input type="number" class="form-control" id="sales" name="sales" step="1" min="0" required value="{{ old('sales', $game->sales) }}">
        </div>
  <div class="mb-3">
            <label for="genero" class="form-label">Game genero</label>
            <input type="text" class="form-control" id="genero" name="genero" step="1" min="0" required value="{{ old('genero', $game->genero) }}">
        </div>

  <div class="mb-3">
            <label for="desarrollador" class="form-label">Game desarrollador</label>
            <input type="text" class="form-control" id="desarrollador" name="desarrollador" step="1" min="0" required value="{{ old('desarrollador', $game->desarrollador) }}">
        </div>

  <div class="mb-3">
            <label for="plataforma" class="form-label">Game plataforma</label>
            <input type="text" class="form-control" id="plataforma" name="plataforma" step="1" min="0" required value="{{ old('plataforma', $game->plataforma) }}">
        </div>

        <button type="submit" class="btn btn-success">Submit</button>
    </form>
@endsection
