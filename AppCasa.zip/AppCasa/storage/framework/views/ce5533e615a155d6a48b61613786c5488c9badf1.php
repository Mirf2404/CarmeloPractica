<?php $__env->startSection('title', 'Argo Movie'); ?>

<?php $__env->startSection('content'); ?>
<div class="table-responsive small">
    <table class="table table-striped table-sm">
        <tbody>
            <tr>
                <td>#</td>
                <td><?php echo e($game->id); ?></td>
            </tr>
            <tr>
                <td>Title</td>
                <td><?php echo e($game->title); ?></td>
            </tr>
            <tr>
                <td>Price</td>
                <td><?php echo e($game->price); ?></td>
            </tr>
            <tr>
                <td>Sales</td>
                <td><?php echo e($game->sales); ?></td>
            </tr>
        
           
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/argoApp/resources/views/game/show.blade.php ENDPATH**/ ?>