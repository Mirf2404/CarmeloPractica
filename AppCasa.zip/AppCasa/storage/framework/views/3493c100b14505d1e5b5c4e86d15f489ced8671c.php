<?php $__env->startSection('title', 'Edit Game'); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(url('game/'.$game->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>

        <!-- Inputs del formulario -->
        <div class="mb-3">
            <label for="title" class="form-label">Game title</label>
            <input type="text" class="form-control" id="title" name="title" maxlength="60" required value="<?php echo e(old('title', $game->title)); ?>">
        </div>

        <div class="mb-3">
            <label for="price" class="form-label">Game price</label>
            <input type="number" class="form-control" id="price" name="price" required value="<?php echo e(old('price', $game->price)); ?>">
        </div>

        <div class="mb-3">
            <label for="sales" class="form-label">Game sales</label>
            <input type="number" class="form-control" id="sales" name="sales" step="1" min="0" required value="<?php echo e(old('sales', $game->sales)); ?>">
        </div>

        <button type="submit" class="btn btn-success">Submit</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/argoApp/resources/views/game/edit.blade.php ENDPATH**/ ?>