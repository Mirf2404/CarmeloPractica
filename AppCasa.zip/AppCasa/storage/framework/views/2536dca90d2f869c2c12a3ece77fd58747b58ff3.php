<?php $__env->startSection('title', 'Argo Movie'); ?>

<?php $__env->startSection('content'); ?>
<div class="table-responsive small">
    <table class="table table-striped table-sm">
        <tbody>
            <tr>
                <td>#</td>
                <td><?php echo e($game->id); ?></td>
            </tr>
            <tr>
                <td>Title</td>
                <td><?php echo e($game->title); ?></td>
            </tr>
            <tr>
                <td>Price</td>
                <td><?php echo e($game->price); ?></td>
            </tr>
            <tr>
                <td>Sales</td>
                <td><?php echo e($game->sales); ?></td>
            </tr>
         <tr>
                <td>genero</td>
                <td><?php echo e($game->genero); ?></td>
            </tr>
            <tr>
                <td>desarrollador</td>
                <td><?php echo e($game->desarrollador); ?></td>
            </tr>
             <tr>
                <td>plataforma</td>
                <td><?php echo e($game->plataforma); ?></td>
            </tr>
        </tbody>
    </table>
    <a href="<?php echo e(url('game/' . $game->id . '/edit')); ?>" class="btn btn-success"><i class="fa fa-magic"></i>Edit</a> 
     <a href="<?php echo e(url('game/')); ?>" class="btn btn-primary">Back</a>
     <form class="formDelete" action="<?php echo e(url('game/' . $game->id)); ?>" method="post" style="display: inline-block">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button class="btn-danger btn" type="submit" >Delete</button>
                    </form>
        <form id = "formDelete" action = "<?php echo e(url ('')); ?>" method = "post" style = "display: inline-block"> 
        <script>
    const forms = document.querySelectorAll(".formDelete");
    forms.forEach(function(form){
        form.onsubmit = () => {
            return confirm("Seguro?");
        }
    });
    
    const ahrefs = document.querySelectorAll(".hrefDelete");
    ahrefs.forEach(function(ahref){
        ahref.onclick = (event) => {
            let url = event.target.dataset.url;
            if (confirm('Seguro?')) {
                let formDelete = document.getElementById("formDelete");
                formDelete.action = url;
                event.preventDefault();
                formDelete.submit();
            }
        }
    });
</script>        
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/AppCasa/resources/views/game/show.blade.php ENDPATH**/ ?>