<?php $__env->startSection('title', 'Argo Create Game'); ?> <!-- Cambiar 'Movie' por 'Game' -->
<?php $__env->startSection('content'); ?>
<div class="table-responsive small">
    <table class="table table-striped table-sm">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Title</th>
                <th scope="col">Price</th> <!-- Cambiar 'Director' y 'Year' por 'Price' y 'Sales' -->
                <th scope="col">Sales</th>
                <th scope="col"></th>
            </tr>
        </thead>
        <tbody>
           
            <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <!-- Cambiar 'movies' por 'games' -->
                <tr>
                    <td><?php echo e($game->id); ?></td>
                    <td><?php echo e($game->title); ?></td>
                    <td><?php echo e($game->price); ?></td>
                    <td><?php echo e($game->sales); ?></td>
                    <td>
                        <a href="<?php echo e(url('game/' . $game->id)); ?>" class="btn btn-primary">View</a>
                        <a href="<?php echo e(url('game/' . $game->id . '/edit')); ?>" class="btn btn-primary">Edit</a> 
        <form class="formDelete" action="<?php echo e(url('game/' . $game->id)); ?>" method="post" style="display: inline-block">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button class="btn-danger btn" type="submit" >Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <a class="btn-primary btn" href="<?php echo e(url('game/create')); ?>">Link to create</a>
    <form id = "formDelete" action = "<?php echo e(url ('')); ?>" method = "post" style = "display: inline-block"> 
    <?php echo csrf_field(); ?>
    <?php echo method_field('delete'); ?>
    </form>
</div>

<script>
    const forms = document.querySelectorAll(".formDelete");
    forms.forEach(function(form){
        form.onsubmit = () => {
            return confirm("Seguro?");
        }
    });
    
    const ahrefs = document.querySelectorAll(".hrefDelete");
    ahrefs.forEach(function(ahref){
        ahref.onclick = (event) => {
            let url = event.target.dataset.url;
            if (confirm('Seguro?')) {
                let formDelete = document.getElementById("formDelete");
                formDelete.action = url;
                event.preventDefault();
                formDelete.submit();
            }
        }
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/argoApp/resources/views/game/index.blade.php ENDPATH**/ ?>