<?php $__env->startSection('title', 'Argo Create Game'); ?>
<?php $__env->startSection('content'); ?>
    <h2>Create Game</h2>

    <form action="<?php echo e(url('game')); ?>" method="post">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label for="title" class="form-label">Game Title</label>
            <input type="text" class="form-control" id="title" name="title"  required value="<?php echo e(old('title')); ?>">
        </div>

        <div class="mb-3">
            <label for="price" class="form-label">Game Price</label>
            <input type="number" class="form-control" id="price" name="price" required value="<?php echo e(old('price')); ?>">
        </div>

        <div class="mb-3">
            <label for="sales" class="form-label">Game Sales</label>
            <input type="number" class="form-control" id="sales" name="sales" min="0" required value="<?php echo e(old('sales')); ?>">
        </div>
     <div class="mb-3">
            <label for="genero" class="form-label">Game genero</label>
            <input type="text" class="form-control" id="genero" name="genero" min="0" required value="<?php echo e(old('genero')); ?>">
        </div>
         <div class="mb-3">
            <label for="desarrollador" class="form-label">Game desarrollador</label>
            <input type="text" class="form-control" id="desarrollador" name="desarrollador" min="0" required value="<?php echo e(old('desarrollador')); ?>">
        </div>
         <div class="mb-3">
            <label for="plataforma" class="form-label">Game plataforma</label>
            <input type="text" class="form-control" id="plataforma" name="plataforma" min="0" required value="<?php echo e(old('plataforma')); ?>">
        </div>
        <button type="submit" class="btn btn-success">Submit</button>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/AppCasa/resources/views/game/create.blade.php ENDPATH**/ ?>