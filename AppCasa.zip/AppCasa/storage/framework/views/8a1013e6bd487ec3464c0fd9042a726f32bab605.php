        

<?php $__env->startSection('title', 'Argo Setting'); ?>

<?php $__env->startSection('content'); ?>

<form action="<?php echo e(url('setting')); ?>" method="post">
    
    <?php echo method_field('put'); ?>    
    <?php echo csrf_field(); ?>
    
    <div>
        Behaviour after inserting new movie
    </div>
    
    <input class="form-check-input" type="radio" id="showMovie" name="afterInsert" 
        value="show movies" <?php if(session('afterInsert', 'show movies') == 'show movies'): ?> checked <?php endif; ?>/>
    <label class="form-check-label" for="showMovie">
        Show all movies list
    </label>
    <br>
    <input class="form-check-input" type="radio" id="createMovie" name="afterInsert" 
        value="show create form" <?php if(session('afterInsert', 'show movies') == 'show create form'): ?> checked <?php endif; ?>/>
    <label class="form-check-label" for="createMovie">
        Show create movies form
    </label>
    
    <br><br>
    
    <!--
    <input class="form-check-input" type="radio" id="showMovie2" name="create" value="show movies2" <?php echo e($checkedList); ?>/>
    <label class="form-check-label" for="showMovie2">
        Show all movies list
    </label>
    <br>
    <input class="form-check-input" type="radio" id="createMovie2" name="create" value="show create form2" <?php echo e($checkedCreate); ?>/>
    <label class="form-check-label" for="createMovie2">
        Show create movies form
    </label>
    
    <br><br>
    -->
    
    <label for="editMovie">Behaviour after inserting new movie</label>
    <select name="editMovie" id="editMovie" class="form-select" aria-label="Default select example">
        <option selected hidden>Select</option>
        <option value="EditMovie">Show all movies list</option>
        <option value="showMovie">Show create movies form</option>
    </select>
    <br>
    <button type="submit" class="btn btn-primary">Save setting</button>
</form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('app.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/argoApp/resources/views/setting/index.blade.php ENDPATH**/ ?>